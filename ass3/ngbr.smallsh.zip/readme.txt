Yo, so you are the unlucky chosen to grade my project.
Haha it's not that bad lol.


Just take the smallsh.c file and run it normally through putty
When compiling, use "gcc smallsh.c -o smallsh"
That way, it will run by just inputing "smallsh" in the command line.

I couldn't get my $$ to show my pid correctly, and it ends up doing some weird duplicating of numbers that I failed to understand
within the time frame of this assignment, but other than that, it all appears to be in order.